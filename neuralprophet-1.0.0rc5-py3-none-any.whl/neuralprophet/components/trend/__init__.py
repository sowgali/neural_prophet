from .base import Trend  # noqa: F401
